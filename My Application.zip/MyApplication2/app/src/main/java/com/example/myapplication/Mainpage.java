package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.Set;

public class Mainpage extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT =0;
    private static final int REQUEST_DISCOVER_BT =1;
    ImageView mBlueTv;
    TextView mStatusBlueTv, mPairedTv;
     Button mOnButton, mOffButton, mDiscoverbotton, mPairedbutton,mScandevice;
     BluetoothAdapter mBlueAdapter;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainpage);



        mStatusBlueTv =findViewById(R.id.statusBluetoothTv);
        mPairedTv = findViewById(R.id.pairedTv);
        mBlueTv = findViewById(R.id.bluetoothTv);
        mOnButton = findViewById(R.id.turnon);
        mOffButton = findViewById(R.id.turnoff);
        mDiscoverbotton = findViewById(R.id.discoverable);
        mPairedbutton = findViewById(R.id.pairdevice);
        mScandevice= findViewById(R.id.scandevice);
        mBlueAdapter = BluetoothAdapter.getDefaultAdapter();
        //chack is bluetooth is available
        if(mBlueAdapter== null) {
            mStatusBlueTv.setText("Bluetooth is not available");
        }else{
            mStatusBlueTv.setText(("Bluetooth is available"));
        }

        if(mBlueAdapter.isEnabled()){
            mBlueTv.setImageResource(R.drawable.ic_action_on);
        }else{
            mBlueTv.setImageResource(R.drawable.ic_action_off);
        }

         mOnButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
            if(!mBlueAdapter.isEnabled()){
                showToast("Turning on Bluetooth...");
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                 startActivityForResult(intent,REQUEST_ENABLE_BT);
            }else{
                showToast("Bluetooth is already on");
            }
             }
         });
         mDiscoverbotton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
              if(!mBlueAdapter.isDiscovering()){
                  showToast("Making your device discoverable");
                  Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                  startActivityForResult(intent,REQUEST_DISCOVER_BT);
              }
             }
         });
         mOffButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
              if(mBlueAdapter.isEnabled()){
                  mBlueAdapter.disable();
                  showToast("Turning bluetooth off");
                  mBlueTv.setImageResource(R.drawable.ic_action_off);

              }else{
                  showToast("Bluetooth is already off");
              }
             }
         });
         mPairedbutton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent proceed= new Intent(Mainpage.this, bluepairdevice.class);
                 startActivity(proceed);
             }
         });
        mScandevice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(Mainpage.this, bluescandevice.class);
                startActivity(proceed);
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch(requestCode) {
            case REQUEST_ENABLE_BT:
                if (resultCode == RESULT_OK) {
                    mBlueTv.setImageResource(R.drawable.ic_action_on);
                    showToast("Bluetooth is on");
                }else{
                    showToast("could't on bluetooth");
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void showToast(String msg){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();

    }






}
