package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button buttonproceed;
    private static final int TIME_DELAY= 2000;
    private static long back_pressed;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonproceed= (Button)findViewById(R.id.proceed);

        buttonproceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(MainActivity.this, registerActivity.class);
                startActivity(proceed);
            }
        });

    }
    @Override
    public void onBackPressed() {
        if(back_pressed +TIME_DELAY >System.currentTimeMillis()){
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();

        }else{
            Toast.makeText(this,"Press once again to exit", Toast.LENGTH_SHORT).show();

        }
        back_pressed= System.currentTimeMillis();
    }
}
