package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class essentials extends AppCompatActivity {
    TextView groceryshop;
    TextView googlemap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_essentials);
        groceryshop=findViewById(R.id.grocery);
        groceryshop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(essentials.this, onlineGrocery.class);
                startActivity(proceed);
            }
        });



        googlemap=findViewById(R.id.google_mp);
        googlemap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(essentials.this, GoogleMap.class);
                startActivity(proceed);
            }
        });
    }
}
