package com.example.myapplication;

import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class sampleActivity extends AppCompatActivity {
    private static final int REQUEST_ENABLE_BT =0;

    ImageView mBlueTv;

    TextView mOnButton, mOffButton;
    BluetoothAdapter mBlueAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sample);



        mBlueTv = findViewById(R.id.bluetoothTv1);
        mOnButton = findViewById(R.id.tracesOn);
        mOffButton = findViewById(R.id.tracesOff);

        mBlueAdapter = BluetoothAdapter.getDefaultAdapter();
        //chack is bluetooth is available


        if(mBlueAdapter.isEnabled()){
            mBlueTv.setImageResource(R.drawable.ic_action_on);
        }else{
            mBlueTv.setImageResource(R.drawable.ic_action_off);
        }

        mOnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!mBlueAdapter.isEnabled()){
                    showToast("Turning on Bluetooth to start contact tracing...");
                    Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(intent,REQUEST_ENABLE_BT);
                }else{
                    showToast("Tracing is already working");
                }
            }
        });

        mOffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mBlueAdapter.isEnabled()){
                    mBlueAdapter.disable();
                    showToast("Turning off tracing");
                    mBlueTv.setImageResource(R.drawable.ic_action_off);

                }else{
                    showToast("Tracing is already stop");
                }
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch(requestCode) {
            case REQUEST_ENABLE_BT:
                if (resultCode == RESULT_OK) {
                    mBlueTv.setImageResource(R.drawable.ic_action_on);
                    showToast("Contact tracing enabled");
                }else{
                    showToast("could't on bluetooth");
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void showToast(String msg){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();

    }



}
