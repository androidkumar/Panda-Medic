package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Dashboard extends AppCompatActivity {
    ImageView essential;
    ImageView dash;
    ImageView newsfeed;
    ImageView notifications;
    ImageView profiles;
    private long backPressesTime;
    private static final int TIME_DELAY= 2000;
    private static long back_pressed;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);


        essential=findViewById(R.id.essential1);
        essential.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(Dashboard.this, essentials.class);
                startActivity(proceed);
            }
        });

        dash=findViewById(R.id.dash1);
        dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(Dashboard.this, sampleActivity.class);
                startActivity(proceed);
            }
        });

        newsfeed=findViewById(R.id.newsfeed1);
        newsfeed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(Dashboard.this, newsfeed.class);
                startActivity(proceed);
            }
        });

        notifications=findViewById(R.id.notification1);
        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(Dashboard.this, notification.class);
                startActivity(proceed);
            }
        });

        profiles=findViewById(R.id.profile1);
        profiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent proceed= new Intent(Dashboard.this, profile.class);
                startActivity(proceed);
            }
        });

    }
    @Override
    public void onBackPressed() {
        if(back_pressed +TIME_DELAY >System.currentTimeMillis()){
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();

        }else{
            Toast.makeText(this,"Press once again to exit", Toast.LENGTH_SHORT).show();

        }
        back_pressed= System.currentTimeMillis();
    }

}
